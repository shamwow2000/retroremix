This mod was created by shamwow, with the help of Bandicario for the Dread costume.

Enjoy!!!

(SHAM)ELESS PLUGS
Twitter: https://twitter.com/shamwow2000
YouTube: https://www.youtube.com/channel/UCLJrs4Y5ndmqnlhCpm8BSUQ

Bandicario
Twitter: https://twitter.com/Bandicario
SSBM Textures: https://ssbmtextures.com/author/bandicario/