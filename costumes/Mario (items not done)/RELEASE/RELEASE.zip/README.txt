This mod was created by shamwow, with the help of a few Crystal Melee Tutorials to get the shading just right; not to mention, huge props to Marv for providing a template for Mario's unmirrored hat for the powerup icons!
EDIT: If you are reading this right now, then you have the newest and probably final release of Retro Mario! Thanks for checking it out all the way through :)))))))))))

Mod contains:
-> 2 DAT files for static and animated costumes for each color
-> Two CSPs for each costume: Vanilla styled and Remix Poses
-> Stock Icons for each costume

Enjoy!!!

(SHAM)ELESS PLUGS:
Twitter: https://twitter.com/shamwow2000
YouTube: https://www.youtube.com/channel/UCLJrs4Y5ndmqnlhCpm8BSUQ