This mod was created by shamwow, and will be a part of the build titled Melee: Retro Remix. Use of these costumes is allowed in any build, just be nice and give credit somewhere if you can :)

Also note that there is no Daisy costume to prevent any problems with importing costumes to m-ex systems.

Enjoy!!!

LINK TO DISCORD SERVER
https://discord.gg/RHDtg84VX3

(SHAM)ELESS PLUGS
Twitter: https://twitter.com/shamwow2000
YouTube: https://www.youtube.com/channel/UCLJrs4Y5ndmqnlhCpm8BSUQ
Twitch: https://www.twitch.tv/shamwow2000