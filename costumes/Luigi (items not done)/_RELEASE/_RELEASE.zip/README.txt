This mod was created by shamwow, with the help of a few Crystal Melee Tutorials to get the shading just right.

Contains:
6 costume files, each with a CSP and a stock icon... as well as both banners because it's tradition at this point.
EDIT: If you're reading this, you have the final final final final build of Retro Luigi! Thanks for keeping track of this stuff :)

Enjoy!!!

(SHAM)ELESS PLUGS:
Twitter: https://twitter.com/shamwow2000
YouTube: https://www.youtube.com/channel/UCLJrs4Y5ndmqnlhCpm8BSUQ