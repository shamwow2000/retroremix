This mod was created by shamwow, with the help of a few Crystal Melee Tutorials to get the shading just right.

EDIT: If you're reading this now, you have the newest version of Retro Link. If you wanna use the updated neutral costume with 20XX, simply rename PlLkNr.dat to PlLkNr.lat, and replace the corresponding file using DAT Texture Wizard. Thanks for checking this out all the way through!

Contains:
5 costume files, each with
- Two CSPs
- Stock Icon
As well as both banners for fun :)

Enjoy!!!

(SHAM)ELESS PLUGS:
Twitter: https://twitter.com/shamwow2000
YouTube: https://www.youtube.com/channel/UCLJrs4Y5ndmqnlhCpm8BSUQ