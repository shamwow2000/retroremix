This mod was created by shamwow, with the help of a few Crystal Melee Tutorials to get the shading just right.
NOTE: This is not as well optimized for Crystal Melee as the original skins are due to texture space. The skin will probably(?) work for it, but it's probably best to stick with the OG skins!

Contains:
5 costume files, each with
- Two CSPs
- Stock Icon
As well as both banners for fun :)

Enjoy!!!

(SHAM)ELESS PLUGS:
Twitter: https://twitter.com/shamwow2000
YouTube: https://www.youtube.com/channel/UCLJrs4Y5ndmqnlhCpm8BSUQ