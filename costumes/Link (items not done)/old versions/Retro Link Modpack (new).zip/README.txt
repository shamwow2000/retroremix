This mod was created by shamwow, with the help of a few Crystal Melee Tutorials to get the shading just right.

Contains:
5 costume files, each with
- Two CSPs
- Stock Icon
As well as both banners for fun :)

Enjoy!!!

(SHAM)ELESS PLUGS:
Twitter: https://twitter.com/shamwow2000
YouTube: https://www.youtube.com/channel/UCLJrs4Y5ndmqnlhCpm8BSUQ