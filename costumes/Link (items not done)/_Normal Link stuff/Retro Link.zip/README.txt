This mod was created by shamwow, with the help of a few Crystal Melee Tutorials to get the shading just right.
NOTE: This is not as well optimized for Crystal Melee as the original skins are due to texture space. The skin will probably(?) work for it, but it's probably best to stick with the OG skins!

Contains:
Two CSPs
Stock Icon
Costume file over Neutral

More to come soon!!!

(SHAM)ELESS PLUGS:
Twitter: https://twitter.com/shamwow2000
YouTube: https://www.youtube.com/channel/UCLJrs4Y5ndmqnlhCpm8BSUQ